#!/bin/bash
echo "2022 (c) Давыдов Д.Э."
echo "Обновление менеджера баз данных Параграф 1.22.11.8"

if [[ ! -f /usr/bin/DB_manager_GUI ]]; then
    echo "Менеджер БД не установлен!"
    exit
else
    #копирование дистрибутива
    sudo cp .DB_manager_GUI /usr/bin/
    cd /usr/bin/
    sudo mv .DB_manager_GUI DB_manager_GUI 
    echo "Обновление выполнено успешно!"
    exit
fi

#!/bin/bash
echo "2022 (c) Давыдов Д.Э."
echo "Обновление менеджера баз данных Параграф 1.22.8.29"

#копирование дистрибутива
sudo cp .DB_manager_GUI /usr/bin/
cd /usr/bin/
sudo mv .DB_manager_GUI DB_manager_GUI 

echo "Обновление выполнено успешно!"
echo "Нажмите клавишу ENTER..."
read
exit

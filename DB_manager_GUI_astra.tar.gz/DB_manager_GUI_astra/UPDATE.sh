#!/bin/bash
echo "2022 (c) Давыдов Д.Э."
echo "Обновление менеджера баз данных Параграф 1.22.11.9"

if [[ ! -f /etc/astra_version ]]; then
echo "Необходима ОС Astra Linux!"
exit
fi

if [[ ! -f /usr/bin/DB_manager_GUI ]]; then
    echo "Менеджер БД не установлен!"
    exit
else
    #копирование дистрибутива
    sudo chmod 777 .DB_manager_GUI
    sudo cp .DB_manager_GUI /usr/bin/
    cd /usr/bin/
    sudo mv .DB_manager_GUI DB_manager_GUI
    sudo chmod 777 DB_manager_GUI
    echo "Обновление выполнено успешно!"
    exit
fi

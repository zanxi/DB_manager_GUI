#!/bin/bash
echo "2022 (c) Давыдов Д.Э."
echo "Установка менеджера баз данных Параграф 1.22.11.9"

if [[ ! -f /etc/astra_version ]]; then
echo "Необходима ОС Astra Linux!"
exit
fi

if [[ -f /usr/bin/DB_manager_GUI ]]; then 
    echo "Менеджер БД уже установлен!"
    exit
else
    #запись прав пользователя в sudoers
    echo "Введите имя учетной записи пользователя операционной системы:"
    read USERNAME
    sudo sh -c "echo \"$USERNAME ALL=(ALL) NOPASSWD:/usr/bin/DB_manager_GUI\" >> /etc/sudoers"
    
    sudo chmod 777 .DB_manager_GUI
    sudo chmod 777 .DB_manager_bar
    
    #копирование дистрибутива
    sudo cp .DB_manager_GUI /usr/bin/
    sudo cp .DB_manager_bar /usr/bin/
    sudo cp -r .db_manager_files /home/
    sudo cp .db-manager-cron /etc/cron.d/
    cd /home/.db_manager_files
    sudo chmod 777 *
    cd /usr/bin/
    sudo mv .DB_manager_GUI DB_manager_GUI
    sudo mv .DB_manager_bar DB_manager_bar
    sudo chmod 777 DB_manager_GUI
    sudo chmod 777 DB_manager_bar

    #cron
    cd /etc/cron.d/
    sudo mv .db-manager-cron db-manager-cron
    sudo service cron restart

    #запись параметров в settings
    cd /home/.db_manager_files
    sudo echo "0" >> settings
    sudo echo "/var/bases/prg3/" >> settings
    sudo echo "masterkey" >> settings
    sudo echo "12345678" >> settings
    sudo echo "$USERNAME" >> settings

    cd $HOME

    echo "[Desktop Entry]
            Name=Менеджер БД
            Type=Application
            NoDisplay=false
            Exec=sudo /usr/bin/DB_manager_GUI
            Icon=/home/.db_manager_files/db_logo.png
            Hidden=false
            Terminal=false
            StartupNotify=false" > db_manager.desktop
            
    mv db_manager.desktop $HOME/Desktop

    echo "Установка выполнена успешно!"
    echo "Компьютер будет перезагружен! Нажмите клавишу ENTER..."
    read
    sudo reboot
    exit
fi

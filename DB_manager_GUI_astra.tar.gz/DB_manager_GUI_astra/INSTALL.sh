#!/bin/bash
echo "2022 (c) Давыдов Д.Э."
echo "Установка менеджера баз данных Параграф"

sudo cp .DB_manager_GUI /usr/bin/
sudo cp .DB_manager_bar /usr/bin/
sudo cp -r .db_manager_files /home/
cd /home/.db_manager_files
sudo chmod 777 *
cd /usr/bin/
sudo mv .DB_manager_GUI DB_manager_GUI
sudo mv .DB_manager_bar DB_manager_bar
sudo chmod 777 DB_manager_GUI
sudo chmod 777 DB_manager_bar
cd $HOME

echo "[Desktop Entry]
        Name=Менеджер БД
        Type=Application
        NoDisplay=false
        Exec=sudo /usr/bin/DB_manager_GUI
        Icon=/home/.db_manager_files/db_logo.png
        Hidden=false
        Terminal=false
        StartupNotify=false" > db_manager.desktop
        
mv db_manager.desktop $HOME/Desktop

echo "Введите имя учетной записи пользователя:"
read USERNAME
sudo sh -c "echo \"$USERNAME ALL=(ALL) NOPASSWD:/usr/bin/DB_manager_GUI\" >> /etc/sudoers"

cd /home/.db_manager_files
sudo echo "$USERNAME" >> settings

echo "Установка выполнена успешно!"
echo "Компьютер будет перезагружен! Нажмите клавишу ENTER..."
read
sudo reboot
exit


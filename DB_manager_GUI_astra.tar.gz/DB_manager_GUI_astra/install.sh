#!/bin/bash
echo "2022 (c) Давыдов Д.Э., davydov@school416spb.ru"
echo "Менеджер баз данных АИСУ Параграф 3, версия 1.22.11.23"
if [[ ! -f /etc/astra_version ]]; then
echo "Необходима ОС Astra Linux!"
exit
fi
echo "Выберите действие:"
echo "1 - Установить Менеджер БД"
echo "2 - Обновить Менеджер БД"
echo "3 - Удалить Менеджер БД"
echo "4 - Выйти"
read ACTION
case $ACTION in
    1)  if [[ -f /usr/bin/DB_manager_GUI ]]; then echo "Менеджер БД уже установлен!"; exit; fi;
        #запись прав пользователя в sudoers
        sudo sh -c "echo \"$USER ALL=(ALL) NOPASSWD:/usr/bin/DB_manager_GUI\" >> /etc/sudoers";
        sudo chmod 777 .DB_manager_GUI;
        sudo chmod 777 .DB_manager_bar;
        #копирование дистрибутива
        sudo cp .DB_manager_GUI /usr/bin/;
        sudo cp .DB_manager_bar /usr/bin/;
        sudo cp -r .db_manager_files /home/;
        sudo cp .db-manager-cron /etc/cron.d/;
        cd /home/.db_manager_files;
        sudo chmod 777 *;
        cd /usr/bin/;
        sudo mv .DB_manager_GUI DB_manager_GUI;
        sudo mv .DB_manager_bar DB_manager_bar;
        sudo chmod 777 DB_manager_GUI;
        sudo chmod 777 DB_manager_bar;
        #cron
        cd /etc/cron.d/;
        sudo mv .db-manager-cron db-manager-cron;
        sudo service cron restart;
        #запись параметров в settings
        cd /home/.db_manager_files;
        sudo echo "0" >> settings;
        sudo echo "/var/bases/prg3/" >> settings;
        sudo echo "masterkey" >> settings;
        sudo echo "12345678" >> settings;
        sudo echo "$USER" >> settings;
        cd $HOME;
        echo "[Desktop Entry]
                Name=Менеджер БД
                Type=Application
                NoDisplay=false
                Exec=sudo /usr/bin/DB_manager_GUI
                Icon=/home/.db_manager_files/db_logo.png
                Hidden=false
                Terminal=false
                StartupNotify=false" > db_manager.desktop;
        mv db_manager.desktop $HOME/Desktop;
        echo "Установка выполнена успешно!";
        echo "Компьютер будет перезагружен! Нажмите клавишу ENTER...";
        read;
        sudo reboot;
        exit;;
    2)  if [[ ! -f /usr/bin/DB_manager_GUI ]]; then echo "Менеджер БД не установлен!"; exit; fi;
        #копирование дистрибутива
        sudo chmod 777 .DB_manager_GUI;
        sudo cp .DB_manager_GUI /usr/bin/;
        cd /usr/bin/;
        sudo mv .DB_manager_GUI DB_manager_GUI;
        sudo chmod 777 DB_manager_GUI;
        sudo echo "no" > /home/.db_manager_files/backup_settings;
        sudo echo "-" >> /home/.db_manager_files/backup_settings;
        if [[ ! -f /home/.db_manager_files/prg3_upgrade.sh ]]; then touch /home/.db_manager_files/prg3_upgrade.sh; cd /home/.db_manager_files; sudo chmod 777 *; fi;
        if [[ ! -f /home/.db_manager_files/dg_upgrade.sh ]]; then touch /home/.db_manager_files/dg_upgrade.sh; cd /home/.db_manager_files; sudo chmod 777 *; fi;
        echo "Обновление выполнено успешно!";
        echo "Не забудьте заново запустить расписание автобэкапа!";
        exit;;
    3)  if [[ ! -f /usr/bin/DB_manager_GUI ]]; then echo "Менеджер БД не установлен!"; exit; fi;
        #удаление файлов и дистрибутива
        cd /usr/bin/;
        sudo rm DB_manager_GUI;
        sudo rm DB_manager_bar;
        cd /home/;
        sudo rm -r .db_manager_files;
        #удаление задачи крон
        cd /etc/cron.d/;
        sudo rm db-manager-cron;
        #удаление из списка sudoers
        sudo sed -i '/DB_manager_GUI/d' /etc/sudoers;
        rm $HOME/Desktop/db_manager.desktop;
        echo "Удаление выполнено успешно...";
        echo "Компьютер будет перезагружен! Нажмите клавишу ENTER...";
        read;
        sudo reboot;
        exit;;
    4)  exit;;
esac

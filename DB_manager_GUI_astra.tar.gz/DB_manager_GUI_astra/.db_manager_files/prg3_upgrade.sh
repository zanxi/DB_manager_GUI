#!/bin/bash
cd /home/superuser/paragraf_linux/
sed -i "s/read set/set=1/" install_server.sh
sed -i "s/read -s password/password=masterkey/" install_server.sh
chmod u+x install_server.sh
./install_server.sh superuser
cd /var/bases/prg3/
sudo chown firebird:firebird *.FDB
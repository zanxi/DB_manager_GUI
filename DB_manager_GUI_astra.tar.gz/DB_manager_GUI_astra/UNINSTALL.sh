#!/bin/bash
echo "2022 (c) Давыдов Д.Э."
echo "Удаление менеджера баз данных Параграф 1.22.7.14"

#удаление файлов и дистрибутива
cd /usr/bin/
sudo rm DB_manager_GUI
sudo rm DB_manager_bar
cd /home/
sudo rm -r .db_manager_files

#удаление задачи крон
cd /etc/cron.d/
sudo rm db-manager-cron

echo "Удаление выполнено успешно..."

exit
